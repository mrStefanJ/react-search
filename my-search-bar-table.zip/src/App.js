import React from 'react';
import './App.scss';
import ErrorBoundary from './component/ErrorBoundary';
import User from './component/User';
// import UserInput from './component/UserInput';

function App() {
  return (
    <div className="App">
        {/* <UserInput /> */}
        <ErrorBoundary>
          <User />
        </ErrorBoundary>
    </div>
  );
}

export default App;
